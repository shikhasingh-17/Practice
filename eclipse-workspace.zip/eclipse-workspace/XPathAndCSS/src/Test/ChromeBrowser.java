package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Navkant\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://login.salesforce.com/");
		
		/*
		 * driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Shikha");
		 * driver.findElement(By.xpath("//input[@id='password']")).sendKeys("shikha");
		 * driver.findElement(By.xpath("//input[@id='Login']")).click();
		 */
		
		//driver.findElement(By.cssSelector("a[id*='forgot']")).click();
		driver.findElement(By.xpath("//*[contains(@id,'domain')]")).click();
		
		

	}

}
