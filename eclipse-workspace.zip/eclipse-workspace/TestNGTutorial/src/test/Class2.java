package test;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Class2 {
	
	@Test
	public void test3()
	{
		System.out.println("test3");
	}
	
	@BeforeClass
	public void bClass()
	{
		System.out.println("Before Class");
	}
	
	@Test(groups = {"Smoke"})
	public void test4()
	{
		System.out.println("test4");
	}
	
	@BeforeSuite
	public void bSiute()
	{
		System.out.println("Before Suite");
	}
	
	@Test
	public void test5()
	{
		System.out.println("test5");
	}
}
