package test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Class4 {
	
	@Test
	public void test41()
	{
		System.out.println("test41");
	}
	
	@BeforeTest
	public void BeforeTest()
	{
		System.out.println("Before Test");
	}
}
