package test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Class3 {
	
	@Test(groups = {"Smoke"})
	public void test32()
	{
		System.out.println("test32");
	}
	

	@AfterSuite
	public void aftrsuite()
	{
		System.out.println("After Suite");
	}
	
	@Parameters({"URL"})
	@Test
	public void test31(String user)
	{
		System.out.println("test31");
		System.out.println(user);
	}

}