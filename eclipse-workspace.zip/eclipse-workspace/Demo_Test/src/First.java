import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Launch chrome browser		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Navkant\\Downloads\\chromedriver_win32\\chromedriver.exe") ;
		WebDriver driver = new ChromeDriver();
		
		//navigate to google.com
		driver.get("https://www.testandquiz.com/selenium/testing.html");		
		
		//search for Javatpoint
//		WebElement search = driver.findElement(By.name("q"));
//		search.sendKeys("JavaTPoint");
//		search.sendKeys(Keys.ENTER);
//		
		//from the search results click on the www.javatpoint.com link
		//driver.findElement(By.partialLinkText("javatpoint.com")).click();
	}

}
