package Practice;

public class Pallindrome {
	
	
	  public static String checkPallindrome(String str) {
	  
	  char arr[] = str.toCharArray(); String rev = ""; for (int i =
	  str.length()-1;i>=0;i--) rev += arr[i];
	  
	  if(str.equals(rev)) return "String is Pallindrome"; else return
	  "String is NOT Pallindrome";
	  
	  
	  }
	 
	public static String checkPallindrome(int n) {
		
		int rev =0;
		int m = n;
		
		while (m!=0) {
			rev = (rev*10)+(m%10);
			m=m/10;
			}
		
		if(n == rev)
			return "Number is Pallindrome";
		else 
			return "Number is NOT Pallindrome";
		
		
	}

}
