package Practice;

public class Strings {
	// a function which takes a string parameter and returns a string value
	public static String revString (String str) {
		
		//to convert string to character array
		char []ch = str.toCharArray();
		String rev = "";
		//System.out.println(ch.length-1);
		for(int i = ch.length-1;i>=0;i--)
		{
			rev += ch[i];
		}		
		return rev;		
	}
	
	public static StringBuffer removeSpaces (String str) {
		char []ch = str.toCharArray();
		StringBuffer sb = new StringBuffer();
		
		for (int i = 0;i<ch.length; i++) {
			if((ch[i]!=' ' ) && (ch[i]!='\t'))
				sb.append(ch[i]);
		}
		return sb;	
			
	}
	
	
}

