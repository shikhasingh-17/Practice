package Practice;

public class DuplicateCharacters {
	
	public static void noOfDuplicates(String str) {
		int count = 0;
		char []ch = str.toCharArray();
		int len = str.length();
		String newStr = "";
		newStr += ch[0];
		
		
		for(int i=0; i<len; i++) {
			for(int j=i+1;j<len;j++) {
				if(ch[i] == ch[j]) {
					System.out.println(ch[j]);
					count++;
				}
			}
		}
		System.out.println("no.ofrepetitions = "+count);
	}

}
