package Practice;

public class Swapping {

	public static void swap(int x, int y) {
		x = x+y;
		y = x-y;
		x = x-y;
		System.out.println("Values after swapping: x = "+x + "y = " +y);
	}

}
