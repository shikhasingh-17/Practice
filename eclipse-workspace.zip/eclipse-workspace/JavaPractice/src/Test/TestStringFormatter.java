package Test;

import Practice.Strings;
import Practice.Swapping;
import Practice.Pallindrome;
import Practice.PrimeCheck;
import Practice.DuplicateCharacters;
import Practice.Fibonacci;
public class TestStringFormatter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fibonacci.fibSeries(10);
		
		//System.out.println(Strings.removeSpaces("I am Shi  kha Sin  gh"));
		
		//DuplicateCharacters.noOfDuplicates("Shikha");
		//System.out.println(Pallindrome.checkPallindrome("level"));
		
		/*
		 * boolean isPrime; isPrime = PrimeCheck.checkPrime(13);
		 * 
		 * if (isPrime) System.out.println("Prime"); else
		 * System.out.println("Not Prime");
		 */
				
		
		
		
		//System.out.println(Strings.revString("Shikha"));
		/*
		 * int x= 10; int y = 20; System.out.printf("values before swapping: x=" +x +
		 * "y = " +y); Swapping.swap(x, y);
		 */

	}

}
